desktop_oas <- tabPanel("Desktop (OAS)",
                        br(), br(),
                        h2("Desktop OAS Requests are not currently supported"))